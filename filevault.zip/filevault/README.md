# FileVault

Site funcional pra publicar e compartilhar arquivos, com banco de dados de verdade por trás (SQLite). Arraste um arquivo, ele vira um link de download.

## Stack

- **Backend:** Node.js + Express
- **Banco de dados:** SQLite (via `better-sqlite3`) — arquivo local, sem servidor de banco separado
- **Upload:** `multer` (armazenamento em disco, limite de 200MB por arquivo)
- **Frontend:** HTML/CSS/JS puro, sem framework, tema escuro com efeito glass

## Rodando localmente

```bash
npm install
npm start
```

O site sobe em `http://localhost:3000`.

## Estrutura

```
filevault/
├── server.js          # API (upload, listagem, download, exclusão) + banco SQLite
├── public/             # frontend (index.html, style.css, script.js)
├── uploads/             # arquivos publicados ficam aqui (não versionado)
└── db/                 # banco filevault.db (não versionado)
```

## API

| Método | Rota                     | Descrição                          |
|--------|---------------------------|-------------------------------------|
| GET    | `/api/files?q=`           | Lista arquivos (busca opcional)    |
| POST   | `/api/upload`              | Publica um arquivo (`multipart/form-data`, campos `file` e `description`) |
| GET    | `/api/files/:id/download`  | Baixa o arquivo e soma no contador |
| DELETE | `/api/files/:id`           | Remove o arquivo e o registro      |

## Publicando no GitHub

```bash
git init
git add .
git commit -m "FileVault: site de publicação de arquivos"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/filevault.git
git push -u origin main
```

> **Importante:** isso é um app com backend (Node + banco de dados), então **GitHub Pages não serve pra hospedar** — Pages só entrega arquivos estáticos. O código fica no GitHub normalmente, mas pra colocar o site no ar você precisa de um host que rode Node, por exemplo:
> - [Railway](https://railway.app)
> - [Render](https://render.com)
> - [Fly.io](https://fly.io)
>
> Em qualquer um deles: conecte o repositório do GitHub, defina o comando de start (`npm start`) e pronto — o deploy acontece a partir do próprio repo.

## Próximos passos possíveis

- Autenticação simples pra restringir quem pode publicar/excluir
- Expiração automática de arquivos (ex: apagar após X dias)
- Links com senha ou data de expiração
