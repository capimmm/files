const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const { nanoid } = require('nanoid');

const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const DB_PATH = path.join(__dirname, 'db', 'filevault.db');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(path.dirname(DB_PATH))) fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

// ---------- Banco de dados ----------
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    original_name TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    description TEXT DEFAULT '',
    mimetype TEXT,
    size INTEGER,
    downloads INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

const stmts = {
  insert: db.prepare(`INSERT INTO files (id, original_name, stored_name, description, mimetype, size)
                       VALUES (@id, @original_name, @stored_name, @description, @mimetype, @size)`),
  list: db.prepare(`SELECT * FROM files ORDER BY created_at DESC`),
  search: db.prepare(`SELECT * FROM files WHERE original_name LIKE @q OR description LIKE @q ORDER BY created_at DESC`),
  get: db.prepare(`SELECT * FROM files WHERE id = ?`),
  bumpDownloads: db.prepare(`UPDATE files SET downloads = downloads + 1 WHERE id = ?`),
  remove: db.prepare(`DELETE FROM files WHERE id = ?`),
};

// ---------- Upload (multer) ----------
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const id = nanoid(10);
    const ext = path.extname(file.originalname);
    cb(null, `${id}${ext}`);
    req._generatedId = id;
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB
});

// ---------- App ----------
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Listar / buscar arquivos
app.get('/api/files', (req, res) => {
  const q = (req.query.q || '').trim();
  const rows = q ? stmts.search.all({ q: `%${q}%` }) : stmts.list.all();
  res.json(rows);
});

// Upload de novo arquivo
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Nenhum arquivo enviado.' });

  const id = path.parse(req.file.filename).name;
  const record = {
    id,
    original_name: req.file.originalname,
    stored_name: req.file.filename,
    description: (req.body.description || '').slice(0, 300),
    mimetype: req.file.mimetype,
    size: req.file.size,
  };
  stmts.insert.run(record);
  res.status(201).json(stmts.get.get(id));
});

// Download de um arquivo (incrementa contador)
app.get('/api/files/:id/download', (req, res) => {
  const file = stmts.get.get(req.params.id);
  if (!file) return res.status(404).json({ error: 'Arquivo não encontrado.' });

  const filePath = path.join(UPLOAD_DIR, file.stored_name);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'Arquivo ausente no disco.' });

  stmts.bumpDownloads.run(file.id);
  res.download(filePath, file.original_name);
});

// Excluir um arquivo
app.delete('/api/files/:id', (req, res) => {
  const file = stmts.get.get(req.params.id);
  if (!file) return res.status(404).json({ error: 'Arquivo não encontrado.' });

  const filePath = path.join(UPLOAD_DIR, file.stored_name);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  stmts.remove.run(file.id);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`FileVault rodando em http://localhost:${PORT}`);
});
