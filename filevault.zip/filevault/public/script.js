const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const browseBtn = document.getElementById('browseBtn');
const dzProgressBar = document.getElementById('dzProgressBar');
const descRow = document.getElementById('descRow');
const descInput = document.getElementById('descInput');
const confirmUpload = document.getElementById('confirmUpload');
const cancelUpload = document.getElementById('cancelUpload');
const grid = document.getElementById('grid');
const empty = document.getElementById('empty');
const count = document.getElementById('count');
const stats = document.getElementById('stats');
const searchInput = document.getElementById('searchInput');
const cardTpl = document.getElementById('cardTpl');

let pendingFile = null;
let allFiles = [];

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDate(iso) {
  const d = new Date(iso + 'Z');
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

function extOf(name) {
  const parts = name.split('.');
  return parts.length > 1 ? parts.pop() : 'file';
}

function render(files) {
  grid.innerHTML = '';
  empty.hidden = files.length > 0;
  count.textContent = files.length ? `${files.length} arquivo${files.length > 1 ? 's' : ''}` : '';
  stats.textContent = `${allFiles.length} arquivo${allFiles.length === 1 ? '' : 's'} guardado${allFiles.length === 1 ? '' : 's'}`;

  for (const f of files) {
    const node = cardTpl.content.cloneNode(true);
    node.querySelector('.ext').textContent = extOf(f.original_name);
    node.querySelector('.name').textContent = f.original_name;
    node.querySelector('.desc').textContent = f.description || '';
    node.querySelector('.size').textContent = formatSize(f.size);
    node.querySelector('.downloads').textContent = `${f.downloads} download${f.downloads === 1 ? '' : 's'}`;
    node.querySelector('.date').textContent = formatDate(f.created_at);
    const dl = node.querySelector('.download');
    dl.href = `/api/files/${f.id}/download`;
    node.querySelector('.del').addEventListener('click', () => removeFile(f.id));
    grid.appendChild(node);
  }
}

async function loadFiles(q = '') {
  const res = await fetch(`/api/files${q ? `?q=${encodeURIComponent(q)}` : ''}`);
  const data = await res.json();
  if (!q) allFiles = data;
  render(data);
}

async function removeFile(id) {
  if (!confirm('Excluir esse arquivo permanentemente?')) return;
  await fetch(`/api/files/${id}`, { method: 'DELETE' });
  loadFiles(searchInput.value.trim());
}

function beginUpload(file) {
  pendingFile = file;
  descRow.hidden = false;
  descInput.value = '';
  descInput.focus();
}

function resetDropzone() {
  pendingFile = null;
  descRow.hidden = true;
  dzProgressBar.style.width = '0%';
  fileInput.value = '';
}

async function doUpload() {
  if (!pendingFile) return;
  const fd = new FormData();
  fd.append('file', pendingFile);
  fd.append('description', descInput.value.trim());

  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/upload');
  xhr.upload.onprogress = (e) => {
    if (e.lengthComputable) {
      dzProgressBar.style.width = `${(e.loaded / e.total) * 100}%`;
    }
  };
  xhr.onload = () => {
    if (xhr.status === 201) {
      resetDropzone();
      loadFiles();
    } else {
      alert('Falha ao publicar o arquivo.');
      resetDropzone();
    }
  };
  xhr.onerror = () => {
    alert('Erro de conexão ao enviar.');
    resetDropzone();
  };
  xhr.send(fd);
}

browseBtn.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('click', (e) => {
  if (e.target === browseBtn) return;
  fileInput.click();
});
fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) beginUpload(fileInput.files[0]);
});

['dragenter', 'dragover'].forEach(evt =>
  dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.add('drag'); })
);
['dragleave', 'drop'].forEach(evt =>
  dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.remove('drag'); })
);
dropzone.addEventListener('drop', (e) => {
  const file = e.dataTransfer.files[0];
  if (file) beginUpload(file);
});

confirmUpload.addEventListener('click', doUpload);
cancelUpload.addEventListener('click', resetDropzone);

let searchTimer;
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => loadFiles(searchInput.value.trim()), 200);
});

loadFiles();
